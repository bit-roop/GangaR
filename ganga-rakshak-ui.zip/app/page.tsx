const desktopStats = [
  { title: "Water Quality Index", value: "78", suffix: "/100", detail: "Moderate", tone: "amber" },
  { title: "River Flow Status", value: "Normal", detail: "Discharge: 2,350 m³/s", tone: "green" },
  { title: "Dolphin Sightings", value: "12", detail: "Spotted today", tone: "blue" },
  { title: "Active Alerts", value: "2", detail: "1 Pollution Alert\n1 Flood Alert", tone: "red" }
];

const biodiversityCards = [
  { name: "Ganges River Dolphin", meta: "Platanista gangetica", status: "Endangered" },
  { name: "Indian Softshell Turtle", meta: "Nilssonia gangetica", status: "Vulnerable" },
  { name: "Sarus Crane", meta: "Grus antigone", status: "Near Threatened" }
];

const mobileTiles = [
  { label: "River Flow", value: "Normal" },
  { label: "Dolphin Sightings", value: "12" },
  { label: "Active Alerts", value: "2" }
];

const quickActions = ["Report Issue", "Check River Health", "Biodiversity Map", "Flood Updates"];

export default function HomePage() {
  return (
    <main className="page-shell">
      <section className="desktop-frame">
        <aside className="sidebar">
          <div className="brand">
            <div className="brand-mark">◌</div>
            <div>
              <h1>GangaRakshak AI</h1>
              <p>Our River. Our Future.</p>
            </div>
          </div>

          <nav className="menu">
            {[
              "Dashboard",
              "River Health",
              "Biodiversity",
              "Flood Prediction",
              "Reports",
              "Traditional Knowledge",
              "Map Explorer",
              "Community",
              "Alerts & News",
              "Settings"
            ].map((item, index) => (
              <a key={item} className={index === 0 ? "menu-item active" : "menu-item"}>
                <span className="menu-dot" />
                {item}
              </a>
            ))}
          </nav>
        </aside>

        <div className="desktop-content">
          <header className="topbar">
            <div>
              <p className="eyebrow">Patna, Bihar</p>
              <h2>Namaste, Ananya 👋</h2>
              <p className="subcopy">Let&apos;s protect our Gangetic ecosystem together.</p>
            </div>

            <div className="topbar-right">
              <div className="weather-chip">
                <span className="weather-icon">⛅</span>
                <div>
                  <strong>26°C</strong>
                  <p>Partly Cloudy</p>
                </div>
              </div>
              <div className="aqi-chip">
                <span>AQI 42</span>
                <strong>Good</strong>
              </div>
              <div className="avatar">A</div>
            </div>
          </header>

          <section className="hero-grid">
            <article className="hero-banner">
              <div className="hero-overlay">
                <h3>
                  Clean River
                  <br />
                  Healthy Future
                </h3>
                <button>Learn More</button>
              </div>
            </article>

            <aside className="thought-card">
              <p className="thought-title">Today&apos;s Thought</p>
              <blockquote>
                “गंगा केवल नदी नहीं,
                <br />
                हमारी संस्कृति, हमारी विरासत है।”
              </blockquote>
              <p className="thought-author">- Traditional Saying</p>
            </aside>
          </section>

          <section className="stats-grid">
            {desktopStats.map((stat) => (
              <article key={stat.title} className="stat-card">
                <p className="stat-title">{stat.title}</p>
                <div className={`stat-value ${stat.tone}`}>
                  {stat.value}
                  {stat.suffix ? <span>{stat.suffix}</span> : null}
                </div>
                <p className={`stat-detail ${stat.tone}`}>
                  {stat.detail.split("\n").map((line) => (
                    <span key={line}>{line}</span>
                  ))}
                </p>
                <p className="stat-time">Last updated: 1 hr ago</p>
              </article>
            ))}
          </section>

          <section className="lower-grid">
            <article className="panel">
              <div className="panel-head">
                <h4>Biodiversity Highlights</h4>
                <span>View All</span>
              </div>
              <div className="species-grid">
                {biodiversityCards.map((card, index) => (
                  <div key={card.name} className="species-card">
                    <div className={`species-image tone-${index + 1}`} />
                    <h5>{card.name}</h5>
                    <p>{card.meta}</p>
                    <strong>{card.status}</strong>
                  </div>
                ))}
              </div>
            </article>

            <article className="panel flood-panel">
              <div className="panel-head">
                <h4>Flood Prediction</h4>
                <span>View Details</span>
              </div>
              <div className="flood-layout">
                <div className="map-preview">
                  <div className="river-line" />
                  <div className="pin">Patna</div>
                </div>
                <div className="risk-card">
                  <p>Moderate Risk</p>
                  <span>Likely rainfall in next 48 hrs</span>
                  <button>See Details</button>
                </div>
              </div>
            </article>
          </section>
        </div>
      </section>

      <section className="mobile-frame">
        <div className="mobile-shell">
          <header className="mobile-top">
            <span>☰</span>
            <strong>Dashboard</strong>
            <span>🔔</span>
          </header>

          <div className="mobile-intro">
            <h3>Namaste, Ananya 👋</h3>
            <p>You are making a difference!</p>
          </div>

          <article className="mobile-quality">
            <p>Water Quality Index</p>
            <div className="mobile-quality-row">
              <div>
                <strong>78</strong>
                <span>/100</span>
                <p>Moderate</p>
              </div>
              <div className="sparkline" />
            </div>
          </article>

          <div className="mobile-tiles">
            {mobileTiles.map((tile) => (
              <div key={tile.label} className="mini-tile">
                <span>{tile.label}</span>
                <strong>{tile.value}</strong>
              </div>
            ))}
          </div>

          <section className="mobile-actions">
            <h4>Quick Actions</h4>
            <div className="action-grid">
              {quickActions.map((action) => (
                <div key={action} className="action-tile">
                  <div className="action-icon" />
                  <span>{action}</span>
                </div>
              ))}
            </div>
          </section>

          <section className="activity-card">
            <div className="panel-head">
              <h4>Recent Activity</h4>
              <span>2 hrs ago</span>
            </div>
            <p>Plastic waste reported near Gandhi Ghat, Patna</p>
          </section>

          <nav className="mobile-nav">
            {["Home", "Map", "+", "Reports", "Profile"].map((item) => (
              <a key={item} className={item === "+" ? "nav-pill active" : "nav-pill"}>
                {item}
              </a>
            ))}
          </nav>
        </div>
      </section>
    </main>
  );
}
